package com.saraya.employemanagement.controller;

import com.saraya.employemanagement.dto.DepartementDto;
import com.saraya.employemanagement.dto.EmployeeDto;
import com.saraya.employemanagement.service.DepartementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/departements")
@RestController
public class DepertementController {

    @Autowired
    private DepartementService service;

    @PostMapping
    public ResponseEntity<Void> save(
            @RequestBody @Validated DepartementDto departementDto) {
        service.save(departementDto);
        return null;
    }

    @GetMapping("/{id}")
    public ResponseEntity<DepartementDto> findById(@PathVariable("id") int id) {
        service.findById(id);
        return null;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") int id) {
        service.deleteById(id);
        return null;
    }

    @GetMapping
    public ResponseEntity<List<DepartementDto>> findAll() {
        service.findAll();
        return null;
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@RequestBody @Validated DepartementDto departementDto, @PathVariable("id") int id) {
        service.update(departementDto);
        return null;
    }
}
