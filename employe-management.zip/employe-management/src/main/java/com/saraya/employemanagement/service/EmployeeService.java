package com.saraya.employemanagement.service;

import com.saraya.employemanagement.dto.EmployeeDto;
import com.saraya.employemanagement.mapper.EmployeeMapper;
import com.saraya.employemanagement.model.Departement;
import com.saraya.employemanagement.model.Employee;
import com.saraya.employemanagement.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class EmployeeService {

    @Autowired
    private EmployeeMapper mapper;
    @Autowired
    private EmployeeRepository repo;

    public EmployeeDto save (EmployeeDto employeeDto){
        return mapper.toDto(repo.save(mapper.toEntity(employeeDto)));
    }

    public void deleteById(int id){
        repo.deleteById(id);
    }

    public EmployeeDto findById(int id){
        Employee employee = repo.findById(id).get();
        return employee != null ? mapper.toDto(employee) :null ;
    }

    public List<EmployeeDto> findAll(){
        return (List<EmployeeDto>) mapper.toDto((Departement) repo.findAll());
    }

    public EmployeeDto update(EmployeeDto employeeDto){
        return mapper.toDto(repo.save(mapper.toEntity(employeeDto)));
    }
}
