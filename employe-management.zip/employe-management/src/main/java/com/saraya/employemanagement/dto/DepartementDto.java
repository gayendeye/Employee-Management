package com.saraya.employemanagement.dto;

import com.saraya.employemanagement.model.Employee;

import javax.persistence.Column;
import javax.persistence.OneToMany;
import java.util.List;

public class DepartementDto extends AbstractDto<Integer> {
    private String initials;

    private String name;

    private List<EmployeeDto> manager;

    private List<EmployeeDto> employees;

    public String getInitials() {
        return initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public List<EmployeeDto> getManager() {
        return manager;
    }

    public void setManager(List<EmployeeDto> manager) {
        this.manager = manager;
    }

    public List<EmployeeDto> getEmployees() {
        return employees;
    }

    public void setEmployees(List<EmployeeDto> employees) {
        this.employees = employees;
    }
}
