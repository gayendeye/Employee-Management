package com.saraya.employemanagement.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Departement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(unique = true)
    private String initials;

    @Column(unique = true)
    private String name;

    @OneToMany
    private List<Employee> manager;

    @OneToMany
    private List<Employee> employees;


    public Departement() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInitials() {
        return initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Employee> getManager() {
        return manager;
    }

    public void setManager(List<Employee> manager) {
        this.manager = manager;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public Departement(int id, String initials, String name, List<Employee> manager, List<Employee> employees) {
        this.id = id;
        this.initials = initials;
        this.name = name;
        this.manager = manager;
        this.employees = employees;
    }
}
