package com.saraya.employemanagement.service;

import com.saraya.employemanagement.dto.DepartementDto;
import com.saraya.employemanagement.mapper.DepartementMapper;
import com.saraya.employemanagement.model.Departement;
import com.saraya.employemanagement.repository.DepartementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class DepartementService {
    @Autowired
    public DepartementMapper mapper;
    @Autowired
    public DepartementRepository repo;

    public DepartementDto save (DepartementDto departementDto){
        return mapper.toDto(repo.save(mapper.toEntity(departementDto)));
    }

    public void deleteById(int id){
        repo.deleteById(id);
    }

    public DepartementDto findById(int id){
        Departement departement = repo.findById(id).get();
     return departement != null ? (DepartementDto) mapper.toDtoDepartement((List<Departement>) departement) :null ;
    }

    public List<DepartementDto> findAll(){
        return mapper.toDtoDepartement(repo.findAll());
    }

    public DepartementDto update(DepartementDto departementDto){
        return mapper.toDto(repo.save(mapper.toEntity(departementDto)));
    }
}
