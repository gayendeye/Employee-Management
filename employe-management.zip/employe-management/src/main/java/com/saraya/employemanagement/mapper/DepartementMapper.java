package com.saraya.employemanagement.mapper;

import com.saraya.employemanagement.dto.DepartementDto;
import com.saraya.employemanagement.dto.EmployeeDto;
import com.saraya.employemanagement.model.Departement;
import com.saraya.employemanagement.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DepartementMapper implements EntityMapper<DepartementDto, Departement>{
@Autowired
    private DepartementMapper departementMapper;
@Autowired
    private EmployeeMapper employeeMapper;
    @Override
    public Departement toEntity(DepartementDto dto) {
        if (dto == null) {
            return null;
        }
        Departement departement = new Departement();
        departement.setId(dto.getId());
        departement.setInitials(dto.getInitials());
        departement.setName(dto.getName());
        departement.setManager((List<Employee>) employeeMapper.toEntity((EmployeeDto) dto.getManager()));
        departement.setEmployees((List<Employee>) employeeMapper.toEntity((EmployeeDto) dto.getEmployees()));
        return departement;
    }

    @Override
    public DepartementDto toDto(Departement entity){
        DepartementDto dto = new DepartementDto();
        dto.setId(entity.getId());
        dto.setInitials(entity.getInitials());
        //dto.setName(entity.getName());
        //dto.setManager(entity.);
        return null;
}
    @Override
    public List<DepartementDto> toDtoDepartement(List<Departement> entityList){
       List<DepartementDto> dtoList = new ArrayList<>();
        for (Departement departement : entityList) {
            DepartementDto dto = (DepartementDto) toDtoDepartement((List<Departement>) departement);
            dtoList.add(dto);
        }
        return dtoList;
    }

    @Override
    public List<Departement> toEntityDepartement(List<DepartementDto> dtoList){
        List<Departement> departments = new ArrayList<>();
        for (DepartementDto dto : dtoList) {
            Departement departement = toEntity(dto);
            departments.add(departement);
        }
        return departments;
    }
    @Override
    public EmployeeDto toDto(Employee entity) {
        return null;
    }

    @Override
    public Employee toEntity(EmployeeDto dto) {
        return null;
    }

    @Override
    public List<Employee> toEntity(List<EmployeeDto> dtoList) {
        return null;
    }

    @Override
    public List<EmployeeDto> toDtoEmployee(List<Employee> entityList) {
        return null;
    }

}
