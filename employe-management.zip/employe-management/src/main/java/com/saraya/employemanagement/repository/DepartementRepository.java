package com.saraya.employemanagement.repository;

import com.saraya.employemanagement.model.Departement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartementRepository extends JpaRepository<Departement , Integer> {
}
