package com.saraya.employemanagement.dto;

public class AbstractDto<T> {

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
