package com.saraya.employemanagement.mapper;

import com.saraya.employemanagement.dto.DepartementDto;
import com.saraya.employemanagement.dto.EmployeeDto;
import com.saraya.employemanagement.model.Departement;
import com.saraya.employemanagement.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeMapper implements EntityMapper<EmployeeDto, Employee> {

    @Autowired
    private EmployeeMapper employeeMapper;
    @Autowired
    private DepartementMapper departementMapper;

    @Override
    public DepartementDto toDto(Departement entity) {
        return null;
    }

    @Override
    public List<DepartementDto> toDtoDepartement(List<Departement> entityList) {
        return null;
    }

    @Override
    public List<Departement> toEntityDepartement(List<DepartementDto> dtoList) {
        return null;
    }

    @Override
    public EmployeeDto toDto(Employee entity){
        EmployeeDto dto = new EmployeeDto();
        dto.setId(entity.getId());
        dto.setFullName(entity.getFullName());
        dto.setHireDate(entity.getHireDate().toString());
        dto.setJob(entity.getJob());
        dto.setSalary(entity.getSalary());
        dto.setAdvantageRate(entity.getAdvantageRate());
        dto.setDepartementDto(dto.getDepartementDto());
        return dto;
    }

    @Override
    public Employee toEntity(EmployeeDto dto){
        if (dto == null){
            return null;
        }
        Employee employee = new Employee();
        employee.setId(dto.getId());
        employee.setFullName(dto.getFullName());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        employee.setHireDate(LocalDate.parse(dto.getHireDate(), formatter));
        employee.setJob(dto.getJob());
        employee.setSalary(dto.getSalary());
        employee.setAdvantageRate(dto.getAdvantageRate());
        employee.setDepartement(departementMapper.toEntity(dto.getDepartementDto()));
        return employee;
    }

    @Override
    public List<Employee> toEntity(List<EmployeeDto> dtoList) {
        List<Employee> employees = new ArrayList<>();
        if (dtoList == null) {
            return employees;
        }
        for (EmployeeDto dto : dtoList){
            Employee order = toEntity(dto);
            employees.add(order);
        }
        return employees;
    }

    @Override
    public List<EmployeeDto> toDtoEmployee(List<Employee> entityList){
        List<EmployeeDto> dtoList = new ArrayList<>();
        for ( Employee employee: entityList) {
            EmployeeDto dto = toDto(employee);
            dtoList.add(dto);
        }
        return dtoList;
    }

    @Override
    public Departement toEntity(DepartementDto dto) {
        return null;
    }

}
