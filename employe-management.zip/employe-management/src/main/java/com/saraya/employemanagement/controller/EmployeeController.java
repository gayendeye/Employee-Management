package com.saraya.employemanagement.controller;

import com.saraya.employemanagement.dto.EmployeeDto;
import com.saraya.employemanagement.service.EmployeeService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RequestMapping("/employees")
@RestController
public class EmployeeController {

    Logger logger = LoggerFactory.getLogger(EmployeeController.class);

    @Autowired
    private EmployeeService service;

    @PostMapping
    public ResponseEntity<Void> save(
            @RequestBody @Validated EmployeeDto employeeDto) {
        service.save(employeeDto);
        return null;
    }

    @GetMapping("/{id}")
    public ResponseEntity<EmployeeDto> findById(@PathVariable("id") int id) {
        service.findById(id);
        return null;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") int id) {
        service.deleteById(id);
        return null;
    }

    @GetMapping
    public ResponseEntity<List<EmployeeDto>> findAll() {
        service.findAll();
        return null;
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@RequestBody @Validated EmployeeDto employeeDto, @PathVariable("id") int id) {
        service.update(employeeDto);
        return null;
    }
}
