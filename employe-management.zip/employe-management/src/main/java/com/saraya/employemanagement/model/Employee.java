package com.saraya.employemanagement.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String fullName;

    @Column(columnDefinition = "date")
    private LocalDate hireDate;

    private String job;

    private double salary;

    private double advantageRate;
    @ManyToOne
    private Departement departement;

    public Employee() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getAdvantageRate() {
        return advantageRate;
    }

    public void setAdvantageRate(double advantageRate) {
        this.advantageRate = advantageRate;
    }

    public Departement getDepartement() {
        return departement;
    }

    public void setDepartement(Departement departement) {
        this.departement = departement;
    }

    public Employee(int id, String fullName, LocalDate hireDate, String job, double salary, double advantageRate, Departement departement) {
        this.id = id;
        this.fullName = fullName;
        this.hireDate = hireDate;
        this.job = job;
        this.salary = salary;
        this.advantageRate = advantageRate;
        this.departement = departement;
    }
}
