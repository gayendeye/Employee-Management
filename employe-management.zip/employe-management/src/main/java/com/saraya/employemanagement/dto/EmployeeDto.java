package com.saraya.employemanagement.dto;

import com.saraya.employemanagement.model.Departement;

import java.util.List;

public class EmployeeDto extends AbstractDto<Integer>{

    private String fullName;

    private String hireDate;

    private String job;

    private double salary;

    private double advantageRate;

    private DepartementDto departementDto;

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getHireDate() {
        return hireDate;
    }

    public void setHireDate(String hireDate) {
        this.hireDate = hireDate;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getAdvantageRate() {
        return advantageRate;
    }

    public void setAdvantageRate(double advantageRate) {
        this.advantageRate = advantageRate;
    }

    public DepartementDto getDepartementDto() {
        return departementDto;
    }

    public void setDepartementDto(DepartementDto departementDto) {
        this.departementDto = departementDto;
    }
}
