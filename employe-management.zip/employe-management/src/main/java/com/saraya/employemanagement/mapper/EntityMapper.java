package com.saraya.employemanagement.mapper;

import com.saraya.employemanagement.dto.DepartementDto;
import com.saraya.employemanagement.dto.EmployeeDto;
import com.saraya.employemanagement.model.Departement;
import com.saraya.employemanagement.model.Employee;

import java.util.List;

public interface EntityMapper<T, T1> {


    DepartementDto toDto(Departement entity);

    List<DepartementDto> toDtoDepartement(List<Departement> entityList);

    List<Departement> toEntityDepartement(List<DepartementDto> dtoList);

    EmployeeDto toDto(Employee entity);

    Employee toEntity(EmployeeDto dto);

    List<Employee> toEntity(List<EmployeeDto> dtoList);

    List<EmployeeDto> toDtoEmployee(List<Employee> entityList);

    Departement toEntity(DepartementDto dto);

}
